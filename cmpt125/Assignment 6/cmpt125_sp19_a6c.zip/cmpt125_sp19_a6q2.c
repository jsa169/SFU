#include <stdio.h>
#include <stdlib.h>

// Node definition for doubly linked list
typedef struct _dllnode  {
    int data;
    struct _dllnode * next;
    struct _dllnode * prev;
} DLLnode_t;

// Definition of doubly linked list
typedef struct {
    DLLnode_t * head;
} DLL_t;

// Creates a doubly linked list
DLL_t * DLLCreate() {
    DLL_t * ret = malloc(sizeof(DLL_t));
    ret->head = NULL;
    return ret;
}

// Appends a DLLnode_t containing the value x into a DLL_t
void DLLAppend(DLL_t * intlist, int x) {
    // Create a DLLnode_t
    DLLnode_t * newNode = malloc(sizeof(DLLnode_t));
    newNode->data = x;
    newNode->prev = NULL;
    newNode->next = NULL;
    
    // Point head to new node if list is empty
    if(intlist->head == NULL) {
        intlist->head = newNode;
        return;
    }
    
    DLLnode_t * temp =intlist->head;
    while(temp->next != NULL) {
        temp = temp->next; // Go To last Node
    }
    
    temp->next = newNode;
    newNode->prev = temp;
}

// Prints the elements of a doubly linked list
void DLLPrint(DLL_t * intlist) {
    DLLnode_t * temp = intlist->head;
    while(temp != NULL) {
        printf("%d ",temp->data);
        temp = temp->next;
    }
    printf("\n");
}
