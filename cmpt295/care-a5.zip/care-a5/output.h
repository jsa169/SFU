
// decompose a float into scientific notation
void f_print(float f); 


// print the hex equivalent of a float
void f_printbits(float f);


