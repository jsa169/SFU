/*
 * test.cpp - Lab 4
 * 
 * Class Description: Test Driver for Patient class
 *
 * Modified on: Oct. 2019
 * Author: AL
 */

#include <iostream>
#include <sstream>
#include "Queue.h"
#include "Patient.h"

using namespace std;


int main () { 

  // Create an empty queue bankQueue
  Queue* aQueue = new Queue();
  string aLine = "";
  string carecard = "";
  string name = "";
  string address = "";
  string phone = "";  
  string email = "";
  Patient* newPatient = NULL;

  cout << "\nTest Driver - Start" << endl << endl;
  // Create and add arrival events to aEventQueue
  while(getline(cin >> ws, aLine)) {   // while (there is data)
      stringstream ss(aLine);
      ss >> carecard >> name >> address >> phone >> email;      
      cout << "Read: " << carecard << ", " << name << ", " << address << ", " << phone << ", " <<  email << endl;  
      newPatient = new Patient(name, address, phone, email, carecard); 
      if ( !aQueue->enqueue(*newPatient) )  return 1;
      cout << *newPatient << endl;
  }
 
  aQueue->printQueue();

  cout << "Test Driver - End" << endl << endl;
  return 0;
}