/*
 * BST.h
 * 
 * Description: Data collection Binary Search Tree ADT class.
 *              Link-based implementation.
 *
 * Class invariant: It is always a BST.
 * 
 * Author: 
 * Date:
 */

	// Put your code here! 

#include "BSTNode.h"
#include "ElementDoesNotExistInBSTException.h"
#include "ElementAlreadyExistsInBSTException.h"

using namespace std;


template <class ElementType>
class BST {
	
private:

	// Put your code here!          
	BSTNode<ElementType> * root;
	int elementCount;
    // Utility methods
    bool insertR(const ElementType& element, BSTNode<ElementType>* current) throw(ElementAlreadyExistsInBSTException);
    ElementType& retrieveR(const ElementType& targetElement, BSTNode<ElementType>* current) const throw(ElementDoesNotExistInBSTException);
	void traverseInOrderR(BSTNode<ElementType> *current) const;
         

public:
    // Constructors and destructor:
	BST();                               // Default constructor
    BST(ElementType& element);           // Parameterized constructor 
	BST(const BST<ElementType>& aBST);   // Copy constructor 
    ~BST();                              // Destructor 
	
    // BST operations:

    // Time efficiency: O(1)
	int getElementCount() const;

	ElementType* getRoot();

	// Time efficiency: O(log2 n)
	void insert(const ElementType& newElement) throw(ElementAlreadyExistsInBSTException);	

	// Time efficiency: O(log2 n)
	ElementType& retrieve(const ElementType& targetElement) throw(ElementDoesNotExistInBSTException);

	// Time efficiency: O(n)
	void traverseInOrder() const;
	
};

	template <class ElementType>
	bool BST<ElementType>::insertR(const ElementType& element, BSTNode<ElementType>* current) throw(ElementAlreadyExistsInBSTException){
		
		if(root == NULL){
			root = new BSTNode<ElementType> (element);
			return true;
		}
		if(element == current->data) {
			throw ElementAlreadyExistsInBSTException("insertR() called with element that already exists");
		}
		if(element < current->data){
			if(current->left == NULL){
				BSTNode<ElementType> *newNode = new BSTNode<ElementType> (element);
				current->left = newNode;
			}else insertR(element, current->left);

		}else{
			if(current->right == NULL){
				BSTNode<ElementType> *newNode = new BSTNode<ElementType> (element);
				current->right = newNode;
			}else insertR(element, current->right);
		}
	}
	
	template <class ElementType>
    ElementType& BST<ElementType>::retrieveR(const ElementType& targetElement, BSTNode<ElementType>* current) const throw(ElementDoesNotExistInBSTException){
    	if(current->getWord() == targetElement) {
    		return current->data;
    	}
    	if(targetElement < current->getWord()) {
    		if(current->left == NULL) {
    			throw ElementDoesNotExistInBSTException("retrieveR() called with element that does not exist in left");
    		}
    		else {
    			retrieveR(targetElement, current->left);
    		}
    	}
    	else {
    		if(current->right == NULL) {
    			throw ElementDoesNotExistInBSTException("retrieveR() called with element that does not exist in right");
    		}
    		else {
    			retrieveR(targetElement, current->right);
    		}
    	}
    }

 	template <class ElementType>
	void BST<ElementType>::traverseInOrderR(BSTNode<ElementType> *current) const{
		if(current == NULL) return;
		else{
			traverseInOrderR(current->left);
			current->printNode();
			traverseInOrderR(current->right);
		}
	}
         

	// Default constructor

	template <class ElementType>
	BST<ElementType>::BST(){
		root = NULL;
		elementCount = 0;
	}
	// Parameterized constructor 

	template <class ElementType>
    BST<ElementType>::BST(ElementType& element){
    	root = element;
    	elementCount = 1;
    }

	// Copy constructor 
	template <class ElementType>
	BST<ElementType>::BST(const BST<ElementType>& aBST){

	}

	// Destructor 	
	template <class ElementType>
    BST<ElementType>::~BST(){

    }                             

    // Time efficiency: O(1)
	template <class ElementType>
	int BST<ElementType>::getElementCount() const{
		return elementCount;
	}

	template <class ElementType>
	ElementType* BST<ElementType>::getRoot(){
		return root;
	}


	// Time efficiency: O(log2 n)
	template <class ElementType>
	void BST<ElementType>::insert(const ElementType& newElement) throw(ElementAlreadyExistsInBSTException){
		try {
			insertR(newElement, root);
			elementCount++;
		} catch (ElementAlreadyExistsInBSTException &anException) {
			throw anException;
		}

	}

	// Time efficiency: O(log2 n)	
	template <class ElementType>
	ElementType& BST<ElementType>::retrieve(const ElementType& targetElement) throw(ElementDoesNotExistInBSTException){
		try {
			return retrieveR(targetElement, root);
		} catch (ElementDoesNotExistInBSTException &anException) {
			throw anException;
		}
	}

	// Time efficiency: O(n)
	template <class ElementType>
	void BST<ElementType>::traverseInOrder() const{
		traverseInOrderR(root);
	}

