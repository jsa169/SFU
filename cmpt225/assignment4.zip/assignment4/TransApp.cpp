/*
 * TransApp.cpp
 * 
 * Description:
 * 
 * Author: 
 * Date:
 */

#include "BST.h"
#include <string>
#include <iostream>
#include <fstream>
#include <stdlib.h>

using namespace std;

int main(){
	system("clear");
	BST<string> b;
	string a;
	ifstream file;
	
	file.open("dataFile.txt");

	while(getline(file, a))
	{
		try {
			if(a == "\0") continue;
			b.insert(a);
		} catch (ElementAlreadyExistsInBSTException &anException) {
			cout << "insert() unsuccessful because " << anException.what() << endl;
			cout << "Duplicates ignored, continuing..." << endl;
			continue;
		}
	}

	file.close();
	
	cout << "Enter word to translate: ";
	while(cin >> a) {
		if(a == "display") {
			b.traverseInOrder();
			break;
		}
		else {
			try {
				cout << "->" << b.retrieve(a) << endl;
				cout << "Enter word to translate: ";
			} catch(ElementDoesNotExistInBSTException &anException) {
				cout << "***Not Found!***\n";
				cout << "Enter word to translate: ";
				continue;
			}
		}

	}

	
	return 0;
}