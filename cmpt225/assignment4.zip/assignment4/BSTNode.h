/*
 * BSTNode.h
 * 
 * Description: Node Class for BST
 * 
 * Author: 
 * Date:
 */

#include <string>
#include <iostream>

using namespace std;

template <class ElementType>
class BSTNode{

public:
	ElementType data;
	BSTNode<ElementType> * right;
	BSTNode<ElementType> * left;

	BSTNode(ElementType newElement);
	void printNode();
	ElementType getWord();
};

template<class ElementType>
BSTNode<ElementType>::BSTNode(ElementType newElement){
	this->data = newElement;
	right = NULL;
	left = NULL;
}

template<class ElementType>
void BSTNode<ElementType>::printNode(){
	cout<<data<<endl;		
}

template<class ElementType>
ElementType BSTNode<ElementType>::getWord(){
	int index = 0;
	while (data[index] != ':'){
		index++;
	}
	ElementType word = data.substr(0, index);

	return word;	
}