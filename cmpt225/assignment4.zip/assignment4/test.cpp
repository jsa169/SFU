#include <iostream>
#include <string>

using namespace std;

int main(){
	
	cout>>endl;
	string a;
	cin >> a;
	cout<<a<<endl;
}